# ♻️ Recycling Drive Dashboard

**Everyday Innovators – Project #47 · Environment & Sustainability**

Track recyclable materials collected by category, validate every entry, and visualise totals, trends and goal forecasts. It has a menu-driven **terminal app** and a **Streamlit web dashboard** that share one tested core.

## Quick start (Windows / Mac / Linux)

Requires **Python 3.10+**.

```bash
python run.py          # installs missing packages, opens the web UI
python run.py --cli    # terminal version
```
Windows: double-click `run.bat`. Mac/Linux: `./run.sh`.
If packages cannot be installed (offline), it falls back to the terminal version automatically.

Manual: `pip install -r requirements.txt` then `streamlit run app.py`.
Tests: `python -m unittest discover -s tests -v` (40 tests).

## 1. Requirements fulfilment

| Brief requirement | Where it is |
|---|---|
| Interactive terminal interface | `cli.py` – 11-option menu, ANSI colours, paginated tables |
| Defensive input validation | `recycling/validation.py` – dates, categories, weight 0.1–500 kg, text rules; prompts loop until valid |
| Core business logic (totals by category) | `recycling/analytics.py` |
| Local persistence (JSON/CSV) | `recycling/storage.py` – JSON, atomic writes, corruption recovery |
| Record query & search | Keyword + category + date range (CLI and web) |
| Executive summary | Totals, averages, top category/collector, best day, trend, goal progress |
| Matplotlib plotting | 5 charts: category bars (goal lines), pie, daily + cumulative trend, goal progress, weekday pattern |
| **Stretch** multi-format export | Markdown, plain-text audit log, CSV, chart PNGs |
| **Stretch** threshold warnings | High entries, anomalies (>3× category average), low progress, inactivity |
| **Stretch** GUI | Streamlit web dashboard (`app.py`) |
| **Stretch** bulk import | `recycling/importer.py` – row-by-row error log |
| Sample dataset 30–50 rows (CSV + JSON) | 40 records in `data/` incl. boundary and edge cases |
| Teacher: UI with Streamlit | `app.py` |
| Teacher: documentation | this README + `docs/ARCHITECTURE.md` |

Also: full CRUD (add, view, **edit**, delete).

## 2. Code quality & best practices
- Layered modules with single responsibilities; type hints throughout; docstrings on every public function.
- Constants and limits live in one place (`config.py`); no magic numbers in the logic.
- 40 unit tests (validation, storage, analytics, import/export, security, CLI input loop).
- GitHub Actions CI (`.github/workflows/ci.yml`) runs the tests on Python 3.10, 3.12 and 3.13.
- `pyproject.toml` with lint config, `.gitignore`, MIT license, pinned dependency ranges.

## 3. Functionality & reliability
- Every failure path is handled: missing/corrupt data file, bad rows, bad CSV rows, missing packages, read-only disk.
- Atomic file writes; corrupt files are backed up, never silently lost.
- Duplicate rows are skipped on import; ids are never reused wrongly.
- Rotating log file (`logs/app.log`) records adds, edits, deletes and imports.

## 4. System design & architecture
See **`docs/ARCHITECTURE.md`** (diagram, data flow, design decisions, failure table).
The terminal and web apps contain no business rules; both call the same `recycling/` package.

## 5. Security & robustness
| Threat | Protection |
|---|---|
| Bad / malicious input | Whitelist validation on every field, length limits, range checks |
| CSV / Excel formula injection | Text starting with `= @` is rejected; `+ -` cells are neutralised on export |
| Markup injection in reports | Markdown escaping of generated text |
| Oversized or hostile uploads | 2 MB file limit, 5000-row import cap, 50 000-record cap |
| Unsafe file paths | CLI import accepts only existing `.csv` files (`safe_csv_path`) |
| Data corruption / crashes | Atomic writes, backups, per-row schema checks on load |
| Accidental deletion | Confirmation prompt (terminal) / checkbox (web) |

## 6. Innovation & technical complexity
- **Goal forecasting:** projects the date each category reaches its goal from its collection rate.
- **Automatic insights:** plain-English findings (dominant category, best weekday, trend, lagging categories).
- **Anomaly detection** (category-relative) and **7-day trend** comparison.
- **CO₂e estimate** from per-material factors (illustrative values).
- **Collector leaderboard**, weekday-pattern analysis, self-installing launcher with graceful fallback.

## Demo script
1. Run `python run.py` → dashboard with metrics, insights, warnings, forecast, charts.
2. **Add Entry** → try `abc`, `-5`, `600` as weight (errors), then `12.5` (saved).
3. **Records & Search** → filter, then **edit** an entry.
4. **Bulk Import** → upload `sample_imports/legacy_with_errors.csv` (4 valid, 8 rejected with reasons).
5. **Charts** and **Export Reports** → download Markdown / TXT / CSV.
6. Close and relaunch → data persists (`data/recycling_data.json`).

## Project structure
```
app.py  cli.py  run.py  run.bat  run.sh  generate_sample_data.py
recycling/  config models validation security storage analytics charts exporter importer log
tests/      test_core.py  test_advanced.py
docs/       ARCHITECTURE.md
data/       recycling_data.json  sample_data.csv  sample_data.json
sample_imports/legacy_with_errors.csv
```

## Known limitations
- Single-user, local JSON storage (by design for a lightweight local tool; a database would be the next step).
- CO₂e factors and category goals are illustrative and editable in `recycling/config.py` / `analytics.py`.
