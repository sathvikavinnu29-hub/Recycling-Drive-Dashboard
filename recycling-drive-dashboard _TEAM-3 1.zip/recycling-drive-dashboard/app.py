"""Streamlit UI for the Recycling Drive Dashboard.

Run:  streamlit run app.py
"""
from __future__ import annotations

from datetime import date

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from recycling import analytics, charts, exporter, importer, storage
from recycling.config import (
    APP_NAME, CATEGORIES, MAX_WEIGHT, MIN_WEIGHT,
)
from recycling.config import MAX_UPLOAD_BYTES
from recycling.validation import ValidationError

st.set_page_config(page_title=APP_NAME, page_icon="♻️", layout="wide")

STATUS_ICON = {"GOAL MET": "🟢", "ON TRACK": "🔵", "BEHIND": "🟡", "CRITICAL": "🔴"}


# ---------- State ----------
def get_records():
    """Load records once per browser session and keep them in session state."""
    if "records" not in st.session_state:
        records, messages = storage.load_records()
        st.session_state.records = records
        st.session_state.load_messages = messages
    return st.session_state.records


def to_df(records) -> pd.DataFrame:
    """Convert records to a DataFrame, newest first."""
    df = pd.DataFrame([r.to_dict() for r in records])
    if df.empty:
        return pd.DataFrame(columns=["id", "date", "category", "item", "weight_kg", "collected_by", "notes"])
    return df.sort_values(["date", "id"], ascending=False).reset_index(drop=True)


def show_df(df):
    """Full-width table; works on both old and new Streamlit versions."""
    try:
        st.dataframe(df, width="stretch", hide_index=True)
    except Exception:
        st.dataframe(df, use_container_width=True, hide_index=True)


def show_fig(fig):
    """Render a Matplotlib figure and free its memory."""
    st.pyplot(fig, clear_figure=True)
    plt.close(fig)


records = get_records()

# ---------- Sidebar ----------
st.sidebar.title("♻️ Recycling Drive")
page = st.sidebar.radio(
    "Navigate",
    ["📊 Dashboard", "➕ Add Entry", "🔎 Records & Search", "📈 Charts", "📤 Export Reports", "📥 Bulk Import"],
)
st.sidebar.divider()
sidebar_stats = st.sidebar.empty()   # filled at the end of the script
for msg in st.session_state.get("load_messages", []):
    st.sidebar.warning(msg)

# ---------- Dashboard ----------
if page == "📊 Dashboard":
    st.title(f"♻️ {APP_NAME}")
    summary = analytics.build_summary(records)
    if summary["empty"]:
        st.info("No data yet. Go to **Add Entry** or **Bulk Import** to get started.")
    else:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total collected", f"{summary['total_kg']:,} kg")
        c2.metric("Entries", summary["total_entries"])
        c3.metric("Avg per entry", f"{summary['average_kg']} kg")
        c4.metric("Trend (7 days)", summary["trend"], f"{summary['trend_change_pct']:+}%")
        c5, c6, c7, c8, c9 = st.columns(5)
        c5.metric("Top category", summary["top_category"])
        c6.metric("Top collector", summary["top_collector"])
        c7.metric("Best day", summary["best_day"][0], f"{summary['best_day'][1]} kg", delta_color="off")
        c8.metric("Avg per active day", f"{summary['avg_per_day']} kg")
        c9.metric("CO₂e avoided (est.)", f"{summary['co2_saved_kg']} kg")

        st.subheader("Goal progress by category")
        for cat, st_info in summary["status"].items():
            left, right = st.columns([1, 4])
            left.write(f"{STATUS_ICON[st_info['status']]} **{cat}** — {st_info['status']}")
            right.progress(min(st_info["percent"] / 100, 1.0),
                           text=f"{st_info['total']:.1f} / {st_info['goal']:g} kg ({st_info['percent']}%)")

        st.subheader("💡 Insights")
        for line in analytics.generate_insights(records):
            st.info(line)

        st.subheader("⚠️ Warnings")
        for w in analytics.generate_warnings(records):
            st.warning(w)

        st.subheader("🔮 Goal forecast")
        st.caption("Projected date each category reaches its goal, at the current collection rate.")
        forecast = pd.DataFrame(analytics.forecast_goals(records))[
            ["category", "status", "rate_kg_per_day", "remaining_kg", "projected_date"]
        ]
        show_df(forecast)

        st.subheader("🏆 Collector leaderboard")
        st.bar_chart(pd.Series(analytics.totals_by_collector(records), name="kg collected"))

        left, right = st.columns(2)
        with left:
            show_fig(charts.category_bar_chart(records))
        with right:
            show_fig(charts.daily_trend_chart(records))

# ---------- Add Entry ----------
elif page == "➕ Add Entry":
    st.title("➕ Add Collection Entry")
    with st.form("add_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        d = c1.date_input("Date", value=date.today(), max_value=date.today())
        cat = c2.selectbox("Category", CATEGORIES)
        item = c1.text_input("Item description", placeholder="e.g. PET bottles")
        weight = c2.text_input(f"Weight (kg, {MIN_WEIGHT}–{MAX_WEIGHT:g})", placeholder="e.g. 12.5")
        by = c1.text_input("Collected by", placeholder="e.g. Ananya")
        notes = c2.text_input("Notes (optional)")
        submitted = st.form_submit_button("Save entry", type="primary")
    if submitted:
        try:
            rec = storage.add_record(records, {
                "date": d, "category": cat, "item": item, "weight_kg": weight,
                "collected_by": by, "notes": notes,
            })
            st.success(f"Saved entry #{rec.id}: {rec.weight_kg:g} kg of {rec.category}.")
            st.balloons()
        except ValidationError as exc:
            st.error(f"❌ {exc}")

# ---------- Records & Search ----------
elif page == "🔎 Records & Search":
    st.title("🔎 Records & Search")
    c1, c2, c3 = st.columns([2, 1, 2])
    kw = c1.text_input("Keyword (item, collector, notes)")
    cat = c2.selectbox("Category", ["All"] + CATEGORIES)
    all_dates = [r.date for r in records]
    if all_dates:
        rng = c3.date_input("Date range", value=(date.fromisoformat(min(all_dates)), date.fromisoformat(max(all_dates))))
        d_from, d_to = (rng[0].isoformat(), rng[1].isoformat()) if len(rng) == 2 else ("", "")
    else:
        d_from = d_to = ""
    results = analytics.search_records(records, kw, "" if cat == "All" else cat, d_from, d_to)
    st.caption(f"{len(results)} record(s) — total {sum(r.weight_kg for r in results):,.2f} kg")
    show_df(to_df(results))

    st.divider()
    st.subheader("✏️ Edit an entry")
    if records:
        edit_id = st.selectbox("Record ID to edit", sorted(r.id for r in records), key="edit_pick")
        rec = next(r for r in records if r.id == edit_id)
        with st.form(f"edit_form_{edit_id}"):
            e1, e2 = st.columns(2)
            e_date = e1.date_input("Date", value=date.fromisoformat(rec.date), max_value=date.today(), key=f"ed_{edit_id}")
            e_cat = e2.selectbox("Category", CATEGORIES, index=CATEGORIES.index(rec.category), key=f"ec_{edit_id}")
            e_item = e1.text_input("Item description", value=rec.item, key=f"ei_{edit_id}")
            e_weight = e2.text_input("Weight (kg)", value=f"{rec.weight_kg:g}", key=f"ew_{edit_id}")
            e_by = e1.text_input("Collected by", value=rec.collected_by, key=f"eb_{edit_id}")
            e_notes = e2.text_input("Notes", value=rec.notes, key=f"en_{edit_id}")
            saved = st.form_submit_button("Update entry", type="primary")
        if saved:
            try:
                storage.update_record(records, edit_id, {
                    "date": e_date, "category": e_cat, "item": e_item,
                    "weight_kg": e_weight, "collected_by": e_by, "notes": e_notes,
                })
                st.success(f"Updated entry #{edit_id}.")
            except ValidationError as exc:
                st.error(f"❌ {exc}")

    st.divider()
    st.subheader("🗑️ Delete an entry")
    if records:
        ids = sorted(r.id for r in records)
        del_id = st.selectbox("Record ID", ids)
        sure = st.checkbox("Yes, I want to delete this record")
        if st.button("Delete selected record", type="secondary", disabled=not sure):
            storage.delete_record(records, del_id)
            st.success(f"Deleted record #{del_id}.")
            st.rerun()

# ---------- Charts ----------
elif page == "📈 Charts":
    st.title("📈 Charts")
    t1, t2, t3, t4, t5 = st.tabs(["By category", "Distribution", "Trend", "Goal progress", "Weekday pattern"])
    with t1:
        show_fig(charts.category_bar_chart(records))
    with t2:
        show_fig(charts.category_pie_chart(records))
    with t3:
        show_fig(charts.daily_trend_chart(records))
    with t4:
        show_fig(charts.goal_progress_chart(records))
    with t5:
        show_fig(charts.weekday_chart(records))

# ---------- Export ----------
elif page == "📤 Export Reports":
    st.title("📤 Export Reports")
    if not records:
        st.info("Nothing to export yet.")
    else:
        md = exporter.summary_to_markdown(records)
        log = exporter.audit_log_text(records)
        csv_text = exporter.records_to_csv_text(records)
        c1, c2, c3 = st.columns(3)
        c1.download_button("⬇ Markdown summary", md, "summary.md", "text/markdown")
        c2.download_button("⬇ Audit log (.txt)", log, "audit_log.txt", "text/plain")
        c3.download_button("⬇ Records CSV", csv_text, "records.csv", "text/csv")
        if st.button("Save all reports + charts to the exports/ folder"):
            files = exporter.export_all(records)
            charts.save_all_charts(records, files["markdown"].parent / "charts")
            st.success("Saved to the `exports/` folder.")
        with st.expander("Preview Markdown report", expanded=True):
            st.markdown(md)

# ---------- Bulk Import ----------
elif page == "📥 Bulk Import":
    st.title("📥 Bulk CSV Import")
    st.caption("Required columns: date, category, item, weight_kg, collected_by (notes optional).")
    up = st.file_uploader("Upload a legacy CSV", type=["csv"])
    if up is not None:
        text = None
        if up.size > MAX_UPLOAD_BYTES:
            st.error(f"File is too large (limit {MAX_UPLOAD_BYTES // 1_000_000} MB).")
        else:
            try:
                text = up.getvalue().decode("utf-8-sig")
            except UnicodeDecodeError:
                st.error("File is not valid UTF-8 text.")
        if text is not None:
            new, errors = importer.import_csv_text(text, records)
            c1, c2 = st.columns(2)
            c1.metric("Valid rows", len(new))
            c2.metric("Rejected rows", len(errors))
            if errors:
                st.subheader("Row-by-row error log")
                for e in errors:
                    st.error(e)
            if new:
                show_df(to_df(new))
                if st.button(f"Import {len(new)} valid rows", type="primary"):
                    records.extend(new)
                    storage.save_records(records)
                    st.success(f"Imported {len(new)} records.")
                    st.rerun()


# ---------- Sidebar totals (drawn last so they always reflect the latest data) ----------
with sidebar_stats.container():
    st.metric("Total records", len(records))
    st.metric("Total collected", f"{sum(r.weight_kg for r in records):,.1f} kg")
