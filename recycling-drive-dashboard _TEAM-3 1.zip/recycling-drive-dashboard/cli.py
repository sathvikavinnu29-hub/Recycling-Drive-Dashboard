"""Terminal interface for the Recycling Drive Dashboard.

Run:  python cli.py
"""
from __future__ import annotations

import os
import sys
from datetime import date

from recycling import analytics, charts, exporter, importer, storage
from recycling.models import Record
from recycling.security import safe_csv_path
from recycling.config import APP_NAME, CATEGORIES, EXPORT_DIR, MAX_WEIGHT, MIN_WEIGHT
from recycling.validation import (
    ValidationError, validate_category, validate_date, validate_text, validate_weight,
)

# ---------- Windows console safety ----------
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if os.name == "nt":
    os.system("")  # enables ANSI colours in the Windows console

# ---------- ANSI helpers ----------
USE_COLOR = sys.stdout.isatty()


def c(text: str, code: str) -> str:
    """Wrap text in an ANSI colour code when the terminal supports it."""
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


GREEN, YELLOW, RED, CYAN, BOLD = "32", "33", "31", "36", "1"
STATUS_COLOR = {"GOAL MET": GREEN, "ON TRACK": CYAN, "BEHIND": YELLOW, "CRITICAL": RED}

BANNER = r"""
  ____                      _ _               ____       _
 |  _ \ ___  ___ _   _  ___| (_)_ __   __ _  |  _ \ _ __(_)_   _____
 | |_) / _ \/ __| | | |/ __| | | '_ \ / _` | | | | | '__| \ \ / / _ \
 |  _ <  __/ (__| |_| | (__| | | | | | (_| | | |_| | |  | |\ V /  __/
 |_| \_\___|\___|\__, |\___|_|_|_| |_|\__, | |____/|_|  |_| \_/ \___|
                 |___/                |___/      DASHBOARD
"""

PAGE_SIZE = 10


# ---------- Centralised input wrappers (loop until valid) ----------
def ask(prompt: str, validator, default: str | None = None):
    """Keep asking until `validator` accepts the input. Blank uses `default` if provided."""
    while True:
        try:
            raw = input(prompt + (f" [{default}]" if default else "") + ": ")
        except EOFError:
            print()
            raise SystemExit(0)
        if not raw.strip() and default is not None:
            raw = default
        try:
            return validator(raw)
        except ValidationError as exc:
            print(c(f"  ✗ {exc}", RED))


def ask_category() -> str:
    """Prompt for a category by name or menu number."""
    print("  Categories: " + ", ".join(f"{i}) {cat}" for i, cat in enumerate(CATEGORIES, 1)))

    def _v(raw: str) -> str:
        raw = raw.strip()
        if raw.isdigit() and 1 <= int(raw) <= len(CATEGORIES):
            return CATEGORIES[int(raw) - 1]
        return validate_category(raw)

    return ask("  Category (name or number)", _v)


def pause() -> None:
    """Wait for Enter so output stays visible."""
    try:
        input(c("\nPress Enter to continue...", CYAN))
    except EOFError:
        pass


# ---------- Table printing with pagination ----------
def print_table(records: list[Record], paginate: bool = True) -> None:
    """Print records as a fixed-width table with pagination."""
    if not records:
        print(c("  No matching records.", YELLOW))
        return
    header = f"{'ID':>4} | {'Date':<10} | {'Category':<8} | {'Item':<24} | {'kg':>7} | {'By':<10}"
    line = "-" * len(header)
    for start in range(0, len(records), PAGE_SIZE):
        print(c(header, BOLD))
        print(line)
        for r in records[start:start + PAGE_SIZE]:
            print(f"{r.id:>4} | {r.date:<10} | {r.category:<8} | {r.item[:24]:<24} | {r.weight_kg:>7.2f} | {r.collected_by[:10]:<10}")
        print(line)
        shown = min(start + PAGE_SIZE, len(records))
        print(f"Showing {start + 1}-{shown} of {len(records)}")
        if paginate and shown < len(records):
            if input("Enter = next page, q = stop: ").strip().lower() == "q":
                break


# ---------- Menu actions ----------
def add_entry(records: list[Record]) -> None:
    """Menu action: collect, validate and save a new entry."""
    print(c("\n== Add New Collection Entry ==", BOLD))
    raw = {
        "date": ask("  Date (YYYY-MM-DD)", validate_date, default=date.today().isoformat()),
        "category": ask_category(),
        "item": ask("  Item description", lambda v: validate_text(v, "Item")),
        "weight_kg": ask(f"  Weight in kg ({MIN_WEIGHT}-{MAX_WEIGHT:g})", validate_weight),
        "collected_by": ask("  Collected by", lambda v: validate_text(v, "Collected by")),
        "notes": ask("  Notes (optional)", lambda v: validate_text(v, "Notes", required=False), default=""),
    }
    rec = storage.add_record(records, raw)
    print(c(f"  ✓ Saved entry #{rec.id}: {rec.weight_kg:g} kg of {rec.category}.", GREEN))


def view_records(records: list[Record]) -> None:
    """Menu action: list all records, newest first."""
    print(c("\n== All Records (newest first) ==", BOLD))
    print_table(sorted(records, key=lambda r: (r.date, r.id), reverse=True))


def search(records: list[Record]) -> None:
    """Menu action: keyword and category search."""
    print(c("\n== Search Records ==", BOLD))
    kw = input("  Keyword (blank = any): ").strip()
    cat = input(f"  Category ({', '.join(CATEGORIES)}; blank = all): ").strip()
    if cat:
        try:
            cat = validate_category(cat)
        except ValidationError as exc:
            print(c(f"  ✗ {exc}", RED))
            return
    results = analytics.search_records(records, keyword=kw, category=cat)
    print_table(sorted(results, key=lambda r: r.date, reverse=True))
    if results:
        print(f"  Matching total: {sum(r.weight_kg for r in results):.2f} kg")


def _validate_id(value: str) -> int:
    if not value.strip().isdigit():
        raise ValidationError("Enter a whole number ID.")
    return int(value)


def delete_entry(records: list[Record]) -> None:
    """Menu action: delete a record after confirmation."""
    print(c("\n== Delete Entry ==", BOLD))
    rid = ask("  Record ID to delete", _validate_id)
    match = next((r for r in records if r.id == rid), None)
    if not match:
        print(c(f"  ✗ No record with ID {rid}.", RED))
        return
    print_table([match], paginate=False)
    if input("  Delete this record? (y/N): ").strip().lower() == "y":
        storage.delete_record(records, rid)
        print(c("  ✓ Deleted.", GREEN))
    else:
        print("  Cancelled.")


def edit_entry(records: list[Record]) -> None:
    """Menu action: edit a record (Enter keeps the current value)."""
    print(c("\n== Edit Entry ==", BOLD))
    rid = ask("  Record ID to edit", _validate_id)
    rec = next((r for r in records if r.id == rid), None)
    if not rec:
        print(c(f"  ✗ No record with ID {rid}.", RED))
        return
    print("  Press Enter to keep the current value.")
    raw = {
        "date": ask("  Date", validate_date, default=rec.date),
        "category": ask("  Category", validate_category, default=rec.category),
        "item": ask("  Item", lambda v: validate_text(v, "Item"), default=rec.item),
        "weight_kg": ask("  Weight (kg)", validate_weight, default=f"{rec.weight_kg:g}"),
        "collected_by": ask("  Collected by", lambda v: validate_text(v, "Collected by"), default=rec.collected_by),
        "notes": ask("  Notes", lambda v: validate_text(v, "Notes", required=False), default=rec.notes or ""),
    }
    storage.update_record(records, rid, raw)
    print(c(f"  ✓ Entry #{rid} updated.", GREEN))


def show_insights(records: list[Record]) -> None:
    """Menu action: print insights and the goal forecast."""
    print(c("\n== Insights ==", BOLD))
    for line in analytics.generate_insights(records):
        print(f"  • {line}")
    print(c("\n== Goal Forecast (at the current collection rate) ==", BOLD))
    print(f"  {'Category':<9} {'kg/day':>7} {'Remaining':>10}  Projected goal date")
    for f in analytics.forecast_goals(records):
        print(f"  {f['category']:<9} {f['rate_kg_per_day']:>7} {f['remaining_kg']:>10}  {f['projected_date']}")


def bar(pct: float, width: int = 25) -> str:
    """Render a text progress bar for a percentage."""
    filled = int(min(pct, 100) / 100 * width)
    return "█" * filled + "░" * (width - filled)


def show_summary(records: list[Record]) -> None:
    """Menu action: print the executive summary."""
    s = analytics.build_summary(records)
    print(c("\n== Executive Summary ==", BOLD))
    if s["empty"]:
        print(c("  No data yet.", YELLOW))
        return
    print(f"  Total collected     : {s['total_kg']} kg in {s['total_entries']} entries")
    print(f"  Average per entry   : {s['average_kg']} kg")
    print(f"  Average per day     : {s['avg_per_day']} kg over {s['active_days']} active days")
    print(f"  Top category        : {s['top_category']}")
    print(f"  Top collector       : {s['top_collector']}")
    print(f"  Best day            : {s['best_day'][0]} ({s['best_day'][1]} kg)")
    print(f"  Trend (7-day)       : {s['trend']} ({s['trend_change_pct']:+}%)")
    print(f"  Est. CO2e avoided   : {s['co2_saved_kg']} kg")
    print(f"  Overall goal        : {s['overall_goal_percent']}%")
    print(c("\n  Category progress", BOLD))
    for cat, st in s["status"].items():
        label = c(f"{st['status']:<9}", STATUS_COLOR[st["status"]])
        print(f"  {cat:<8} {bar(st['percent'])} {st['total']:>7.1f}/{st['goal']:<5g} kg {st['percent']:>6.1f}%  {label}")


def show_warnings(records: list[Record]) -> None:
    """Menu action: print threshold warnings."""
    print(c("\n== Threshold Warnings ==", BOLD))
    for w in analytics.generate_warnings(records):
        print(c(f"  ⚠ {w}", YELLOW))


def make_charts(records: list[Record]) -> None:
    """Menu action: save all charts as PNG files."""
    out = EXPORT_DIR / "charts"
    paths = charts.save_all_charts(records, out)
    print(c("  ✓ Charts saved:", GREEN))
    for p in paths:
        print(f"    {p}")


def export_reports(records: list[Record]) -> None:
    """Menu action: export Markdown, TXT, CSV and charts."""
    files = exporter.export_all(records)
    make_charts(records)
    print(c("  ✓ Reports exported:", GREEN))
    for kind, path in files.items():
        print(f"    {kind:<9}: {path}")


def bulk_import(records: list[Record]) -> None:
    """Menu action: import a CSV with a row-by-row error log."""
    print(c("\n== Bulk CSV Import ==", BOLD))
    path = input("  Path to CSV file (e.g. sample_imports/legacy_with_errors.csv, blank = cancel): ").strip()
    if not path:
        return
    try:
        path = safe_csv_path(path)
    except ValidationError as exc:
        print(c(f"  ✗ {exc}", RED))
        return
    new, errors = importer.import_csv_file(path, records)
    print(f"  Valid rows: {len(new)}   Rejected rows: {len(errors)}")
    for e in errors:
        print(c(f"    ✗ {e}", RED))
    if new and input(f"  Import the {len(new)} valid rows? (y/N): ").strip().lower() == "y":
        records.extend(new)
        storage.save_records(records)
        print(c(f"  ✓ Imported {len(new)} records.", GREEN))


MENU = [
    ("Add new entry", add_entry),
    ("View all records", view_records),
    ("Search / filter records", search),
    ("Executive summary", show_summary),
    ("Threshold warnings", show_warnings),
    ("Generate charts (PNG)", make_charts),
    ("Export reports (MD / TXT / CSV + charts)", export_reports),
    ("Bulk import from CSV", bulk_import),
    ("Delete an entry", delete_entry),
    ("Edit an entry", edit_entry),
    ("Insights & goal forecast", show_insights),
]


def main() -> None:
    """Run the interactive menu loop."""
    print(c(BANNER, GREEN))
    print(c(f"  {APP_NAME} - track recyclables by category, spot trends, hit your goals.\n", BOLD))
    records, messages = storage.load_records()
    for m in messages:
        print(c(f"  ℹ {m}", YELLOW))
    print(f"  Loaded {len(records)} records.\n")

    while True:
        print(c("──────── MAIN MENU ────────", CYAN))
        for i, (label, _) in enumerate(MENU, 1):
            print(f"  {i}. {label}")
        print("  0. Exit")
        try:
            choice = input("\nChoose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break
        if choice == "0":
            print(c("Thank you for recycling! Goodbye.", GREEN))
            break
        if choice.isdigit() and 1 <= int(choice) <= len(MENU):
            try:
                MENU[int(choice) - 1][1](records)
            except KeyboardInterrupt:
                print("\n  (cancelled)")
            pause()
        else:
            print(c("  ✗ Invalid choice. Enter a number from the menu.", RED))


if __name__ == "__main__":
    main()
