# Architecture

The app uses a **layered design**. Both interfaces (terminal and web) are thin front-ends over the
same tested core, so there is exactly one implementation of every rule.

```mermaid
flowchart TD
    subgraph UI["Presentation layer"]
        CLI["cli.py - terminal menu"]
        WEB["app.py - Streamlit web UI"]
    end
    subgraph CORE["Core package: recycling/"]
        VAL["validation.py - input rules"]
        SEC["security.py - CSV-injection, path and size guards"]
        AN["analytics.py - totals, search, summary, forecast, insights"]
        CH["charts.py - Matplotlib charts"]
        EX["exporter.py - MD / TXT / CSV reports"]
        IM["importer.py - bulk CSV import"]
        ST["storage.py - JSON persistence"]
        LOG["log.py - rotating log"]
        CFG["config.py - limits, goals, paths"]
    end
    DATA[("data/recycling_data.json")]
    CLI --> VAL & AN & CH & EX & IM & ST
    WEB --> VAL & AN & CH & EX & IM & ST
    ST --> VAL
    IM --> VAL
    EX --> SEC
    ST --> DATA
    ST --> LOG
    AN --> CFG
    VAL --> CFG
```

## Data flow: adding an entry
1. The UI collects raw text (terminal prompt or web form).
2. `validation.validate_record_fields` cleans and type-checks every field. Bad input raises `ValidationError` with a friendly message; the UI shows it and asks again.
3. `storage.add_record` assigns an id, appends, and writes the JSON file **atomically** (temp file, then replace), so a crash can never leave a half-written file.
4. The change is logged to `logs/app.log`.

## Design decisions
| Decision | Reason |
|---|---|
| One shared validation layer | Bad data cannot enter through the UI, the importer, or a hand-edited file. |
| `Record` dataclass | Typed, self-documenting data model. |
| JSON storage with schema checks | Human-readable, zero dependencies; each row is re-validated on load. |
| Pure functions in `analytics.py` | No I/O, so they are easy to unit test. |
| Matplotlib `Agg` backend | Charts render on any machine, with or without a display. |
| UI holds no business logic | Terminal and web always give identical results. |
| Config in one module | Categories, goals and limits change in one place. |

## Failure handling
| Failure | Behaviour |
|---|---|
| Data file missing | A clean file is created automatically. |
| Data file corrupt | Backed up as `*.corrupt_<time>.json`, then a fresh file is created. |
| One bad stored row | Skipped and reported; the other rows still load. |
| Bad CSV rows | Rejected one by one with the row number and reason. |
| Missing packages | `run.py` installs them, or falls back to the terminal version. |
| Read-only disk for logs | Logging silently disables itself; the app keeps working. |
