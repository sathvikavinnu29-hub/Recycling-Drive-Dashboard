"""Generate realistic sample data (CSV + JSON) and a messy CSV for import testing.

Run:  python generate_sample_data.py
"""
import csv
import random
from datetime import date, timedelta

from recycling.config import DATA_DIR, BASE_DIR
from recycling.models import Record
from recycling.storage import save_records

random.seed(47)

ITEMS = {
    "Plastic": ["PET bottles", "Plastic containers", "Shopping bags", "Packaging film"],
    "Paper": ["Old newspapers", "Cardboard boxes", "Office paper", "Magazines"],
    "Glass": ["Glass bottles", "Glass jars", "Broken window glass"],
    "Metal": ["Aluminium cans", "Steel tins", "Scrap copper wire", "Metal lids"],
    "E-Waste": ["Old phone chargers", "Dead batteries", "Keyboards", "Broken headphones"],
    "Textile": ["Old clothes", "Bedsheets", "Curtains"],
    "Organic": ["Canteen food waste", "Garden leaves", "Fruit peels"],
}
WEIGHT_RANGE = {
    "Plastic": (2, 14), "Paper": (4, 22), "Glass": (3, 16), "Metal": (2, 12),
    "E-Waste": (0.5, 6), "Textile": (1.5, 9), "Organic": (3, 15),
}
PEOPLE = ["Ananya", "Rohit", "Meera", "Karthik", "Sneha", "Imran"]


def build_records(n: int = 40) -> list[Record]:
    """Build n realistic records including boundary and anomaly cases."""
    start = date(2026, 10, 26)
    rows = []
    for i in range(n):
        cat = random.choice(list(ITEMS))
        lo, hi = WEIGHT_RANGE[cat]
        rows.append({
            "date": (start + timedelta(days=random.randint(0, 26))).isoformat(),
            "category": cat,
            "item": random.choice(ITEMS[cat]),
            "weight_kg": round(random.uniform(lo, hi), 1),
            "collected_by": random.choice(PEOPLE),
            "notes": random.choice(["", "", "Campus drive", "Hostel block A", "Dept. collection"]),
        })
    # Boundary values & edge cases for demonstration
    rows[0].update(category="E-Waste", item="Single coin cell battery", weight_kg=0.1, notes="Minimum weight boundary")
    rows[1].update(category="Glass", item="Bulk bottle donation", weight_kg=135.0, notes="Anomaly - bulk donation")
    rows[2].update(category="Metal", item="Scrap yard consignment", weight_kg=100.0, notes="Exactly at high-entry limit")
    rows[3].update(date="2026-11-21", category="Paper", item="Exam paper bundle", weight_kg=48.5, notes="Latest entry")
    rows.sort(key=lambda r: r["date"])
    return [Record(id=i, **r) for i, r in enumerate(rows, start=1)]


def main():
    """Write the sample JSON/CSV files and the messy import CSV."""
    records = build_records(40)
    DATA_DIR.mkdir(exist_ok=True)
    save_records(records, DATA_DIR / "recycling_data.json")
    save_records(records, DATA_DIR / "sample_data.json")
    with open(DATA_DIR / "sample_data.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=Record.field_names())
        w.writeheader()
        w.writerows(r.to_dict() for r in records)

    # Legacy CSV with intentional errors to demo the row-by-row error log
    messy = BASE_DIR / "sample_imports" / "legacy_with_errors.csv"
    messy.parent.mkdir(exist_ok=True)
    rows = [
        "date,category,item,weight_kg,collected_by,notes",
        "2026-11-18,Plastic,Water bottles,6.5,Ananya,Good row",
        "2026-11-19,paper,Cardboard,12,Rohit,Lowercase category is accepted",
        "2026-11-20,Plastik,Bags,3.2,Meera,Bad category",
        "2026-11-20,Glass,Jars,abc,Karthik,Non-numeric weight",
        "2026-13-01,Metal,Cans,4.0,Sneha,Invalid date",
        "2026-11-20,Metal,Cans,-5,Imran,Negative weight",
        "2026-11-20,Metal,Cans,900,Imran,Over maximum",
        "2026-11-21,Textile,,2.5,Ananya,Blank item",
        "2026-11-21,E-Waste,Old mouse,1.2,,Blank collector",
        "2027-05-01,Paper,Future dated,5,Rohit,Future date",
        "2026-11-21,Organic,Fruit peels,7.8,Meera,Good row",
        "2026-11-22,Glass,Jars,9.0,Karthik,Good row",
    ]
    messy.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"Generated {len(records)} records and sample files.")


if __name__ == "__main__":
    main()
