"""Core business logic: totals by category, search/filter, summary, warnings, trends."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta
from statistics import mean

from .config import ANOMALY_FACTOR, CATEGORY_GOALS, HIGH_ENTRY_KG, INACTIVITY_DAYS
from .models import Record


def totals_by_category(records: list[Record]) -> dict[str, float]:
    """Total kg per category, largest first."""
    totals: dict[str, float] = defaultdict(float)
    for r in records:
        totals[r.category] += r.weight_kg
    return {k: round(v, 2) for k, v in sorted(totals.items(), key=lambda kv: -kv[1])}


def counts_by_category(records: list[Record]) -> dict[str, int]:
    """Number of entries per category."""
    counts: dict[str, int] = defaultdict(int)
    for r in records:
        counts[r.category] += 1
    return dict(counts)


def totals_by_date(records: list[Record]) -> dict[str, float]:
    """Total kg per date, in chronological order."""
    totals: dict[str, float] = defaultdict(float)
    for r in records:
        totals[r.date] += r.weight_kg
    return {k: round(totals[k], 2) for k in sorted(totals)}


def totals_by_collector(records: list[Record]) -> dict[str, float]:
    """Total kg per collector, largest first (leaderboard)."""
    totals: dict[str, float] = defaultdict(float)
    for r in records:
        totals[r.collected_by] += r.weight_kg
    return {k: round(v, 2) for k, v in sorted(totals.items(), key=lambda kv: -kv[1])}


def search_records(
    records: list[Record],
    keyword: str = "",
    category: str = "",
    date_from: str = "",
    date_to: str = "",
) -> list[Record]:
    """Keyword (item/collector/notes), category and date-range filtering."""
    kw = keyword.strip().lower()
    cat = category.strip().lower()
    out = []
    for r in records:
        if cat and cat != "all" and r.category.lower() != cat:
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        if kw and kw not in f"{r.item} {r.collected_by} {r.notes} {r.category}".lower():
            continue
        out.append(r)
    return out


def goal_status(total: float, goal: float) -> str:
    """Classify progress toward a goal as GOAL MET / ON TRACK / BEHIND / CRITICAL."""
    pct = total / goal * 100 if goal else 0
    if pct >= 100:
        return "GOAL MET"
    if pct >= 60:
        return "ON TRACK"
    if pct >= 30:
        return "BEHIND"
    return "CRITICAL"


def trend_direction(records: list[Record], window_days: int = 7) -> tuple[str, float]:
    """Compare the last `window_days` against the previous window. Returns (label, % change)."""
    if not records:
        return "NO DATA", 0.0
    latest = max(datetime.strptime(r.date, "%Y-%m-%d").date() for r in records)
    cur_start = latest - timedelta(days=window_days - 1)
    prev_start = cur_start - timedelta(days=window_days)
    cur = prev = 0.0
    for r in records:
        d = datetime.strptime(r.date, "%Y-%m-%d").date()
        if d >= cur_start:
            cur += r.weight_kg
        elif d >= prev_start:
            prev += r.weight_kg
    if prev == 0:
        return ("RISING" if cur > 0 else "FLAT"), 0.0
    change = (cur - prev) / prev * 100
    if change > 5:
        return "RISING", round(change, 1)
    if change < -5:
        return "FALLING", round(change, 1)
    return "STABLE", round(change, 1)


def generate_warnings(records: list[Record], today: date | None = None) -> list[str]:
    """Threshold warning flags: anomalies, goal shortfalls, inactivity."""
    warnings: list[str] = []
    if not records:
        return ["No records yet - add your first collection entry."]
    today = today or date.today()

    by_cat: dict[str, list[float]] = defaultdict(list)
    for r in records:
        by_cat[r.category].append(r.weight_kg)

    for r in records:
        others = [w for w in by_cat[r.category]]
        avg = mean(others) if others else 0
        if r.weight_kg >= HIGH_ENTRY_KG:
            warnings.append(
                f"HIGH ENTRY: #{r.id} {r.item} ({r.category}) is {r.weight_kg:g} kg on {r.date} "
                f"- above the {HIGH_ENTRY_KG:g} kg limit."
            )
        elif len(others) >= 4 and avg > 0 and r.weight_kg > ANOMALY_FACTOR * avg:
            warnings.append(
                f"ANOMALY: #{r.id} {r.item} ({r.category}) is {r.weight_kg:g} kg, "
                f"over {ANOMALY_FACTOR:g}x the category average ({avg:.1f} kg)."
            )

    totals = totals_by_category(records)
    for cat, goal in CATEGORY_GOALS.items():
        status = goal_status(totals.get(cat, 0.0), goal)
        if status == "CRITICAL":
            warnings.append(
                f"LOW PROGRESS: {cat} is at {totals.get(cat, 0.0):.1f} / {goal:g} kg ({status})."
            )

    last = max(datetime.strptime(r.date, "%Y-%m-%d").date() for r in records)
    idle = (today - last).days
    if idle >= INACTIVITY_DAYS:
        warnings.append(f"INACTIVITY: no collections recorded for {idle} days (last: {last}).")
    return warnings


def build_summary(records: list[Record]) -> dict:
    """Executive summary: totals, averages, status indicators and key trends."""
    if not records:
        return {"empty": True, "total_entries": 0, "total_kg": 0.0}

    weights = [r.weight_kg for r in records]
    by_cat = totals_by_category(records)
    by_date = totals_by_date(records)
    collectors = totals_by_collector(records)
    heaviest = max(records, key=lambda r: r.weight_kg)
    best_day = max(by_date.items(), key=lambda kv: kv[1])
    trend, change = trend_direction(records)
    total_goal = sum(CATEGORY_GOALS.values())
    total_kg = round(sum(weights), 2)

    status = {
        cat: {
            "total": by_cat.get(cat, 0.0),
            "goal": goal,
            "percent": round(by_cat.get(cat, 0.0) / goal * 100, 1),
            "status": goal_status(by_cat.get(cat, 0.0), goal),
        }
        for cat, goal in CATEGORY_GOALS.items()
    }
    return {
        "empty": False,
        "total_entries": len(records),
        "total_kg": total_kg,
        "average_kg": round(mean(weights), 2),
        "heaviest_entry": heaviest,
        "top_category": next(iter(by_cat)),
        "by_category": by_cat,
        "counts": counts_by_category(records),
        "top_collector": next(iter(collectors)),
        "best_day": best_day,
        "active_days": len(by_date),
        "avg_per_day": round(total_kg / len(by_date), 2),
        "first_date": min(by_date),
        "last_date": max(by_date),
        "trend": trend,
        "trend_change_pct": change,
        "overall_goal_percent": round(total_kg / total_goal * 100, 1),
        "status": status,
        "co2_saved_kg": estimate_co2_saved(by_cat),
    }


# Rough CO2e savings per kg recycled (kg CO2e / kg material) - illustrative factors.
CO2_FACTORS = {
    "Plastic": 1.5, "Paper": 1.0, "Glass": 0.3, "Metal": 4.0,
    "E-Waste": 2.0, "Textile": 3.0, "Organic": 0.2,
}


def estimate_co2_saved(by_cat: dict[str, float]) -> float:
    """Estimate CO2e avoided (kg) from per-category weights."""
    return round(sum(kg * CO2_FACTORS.get(cat, 0.0) for cat, kg in by_cat.items()), 1)


# ---------------------------------------------------------------------------
# Predictive analytics & automatic insights
# ---------------------------------------------------------------------------
def forecast_goals(records: list[Record]) -> list[dict]:
    """Project when each category will reach its goal, using its average daily collection rate.

    rate = total collected / days in the observed period; days_to_goal = ceil(remaining / rate).
    The projection starts from the date of the latest entry.
    """
    from math import ceil

    if not records:
        return []
    dates = [datetime.strptime(r.date, "%Y-%m-%d").date() for r in records]
    first, last = min(dates), max(dates)
    span_days = max((last - first).days + 1, 1)
    totals = totals_by_category(records)

    rows = []
    for cat, goal in CATEGORY_GOALS.items():
        total = totals.get(cat, 0.0)
        rate = total / span_days
        remaining = max(goal - total, 0.0)
        if remaining == 0:
            row = {"category": cat, "status": "GOAL MET", "days_to_goal": 0,
                   "projected_date": "reached"}
        elif rate <= 0:
            row = {"category": cat, "status": "NO DATA", "days_to_goal": None,
                   "projected_date": "n/a"}
        else:
            days = ceil(remaining / rate)
            row = {"category": cat, "status": goal_status(total, goal), "days_to_goal": days,
                   "projected_date": (last + timedelta(days=days)).isoformat()}
        row.update({"rate_kg_per_day": round(rate, 2), "remaining_kg": round(remaining, 1)})
        rows.append(row)
    return rows


def weekday_totals(records: list[Record]) -> dict[str, float]:
    """Total kg collected per weekday (Monday..Sunday)."""
    order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    totals = {d: 0.0 for d in order}
    for r in records:
        totals[datetime.strptime(r.date, "%Y-%m-%d").strftime("%A")] += r.weight_kg
    return {d: round(v, 2) for d, v in totals.items()}


def generate_insights(records: list[Record]) -> list[str]:
    """Plain-English findings derived from the data."""
    if not records:
        return ["Add some entries to unlock automatic insights."]
    s = build_summary(records)
    out = []
    top_share = s["by_category"][s["top_category"]] / s["total_kg"] * 100
    out.append(f"{s['top_category']} makes up {top_share:.0f}% of everything collected.")
    wd = weekday_totals(records)
    best_wd = max(wd, key=wd.get)
    out.append(f"{best_wd} is the strongest collection day ({wd[best_wd]:.1f} kg in total).")
    if s["trend"] in ("RISING", "FALLING"):
        out.append(f"Collections are {s['trend'].lower()} ({s['trend_change_pct']:+}% vs the previous 7 days).")
    else:
        out.append(f"Collections are {s['trend'].lower()} compared with the previous 7 days.")
    lagging = [c for c, st in s["status"].items() if st["status"] == "CRITICAL"]
    if lagging:
        verb = "is" if len(lagging) == 1 else "are"
        out.append(f"Needs attention: {', '.join(lagging)} {verb} far below the goal.")
    met = [c for c, st in s["status"].items() if st["status"] == "GOAL MET"]
    if met:
        out.append(f"Goals already met: {', '.join(met)}.")
    out.append(f"Estimated CO2e avoided so far: {s['co2_saved_kg']} kg.")
    return out
