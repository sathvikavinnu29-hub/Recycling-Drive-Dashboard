"""Matplotlib charts. Uses a non-interactive backend so it works everywhere."""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from .analytics import totals_by_category, totals_by_date, weekday_totals  # noqa: E402
from .config import CATEGORY_GOALS  # noqa: E402
from .models import Record  # noqa: E402

COLORS = ["#2e7d32", "#1565c0", "#00838f", "#ef6c00", "#6a1b9a", "#ad1457", "#8d6e63"]


def _empty_fig(title: str):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.text(0.5, 0.5, "No data to display", ha="center", va="center", fontsize=14, color="gray")
    ax.set_title(title)
    ax.axis("off")
    return fig


def category_bar_chart(records: list[Record]):
    """Bar chart of total kg per category with dashed goal markers."""
    totals = totals_by_category(records)
    if not totals:
        return _empty_fig("Total Recycled by Category")
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    cats = list(totals)
    vals = [totals[c] for c in cats]
    bars = ax.bar(cats, vals, color=COLORS[: len(cats)])
    for i, c in enumerate(cats):
        goal = CATEGORY_GOALS.get(c)
        if goal:
            ax.hlines(goal, i - 0.4, i + 0.4, colors="black", linestyles="dashed", linewidth=1)
    ax.bar_label(bars, fmt="%.1f", padding=2)
    ax.set_ylabel("Weight (kg)")
    ax.set_title("Total Recycled by Category (dashed line = goal)")
    ax.spines[["top", "right"]].set_visible(False)
    plt.setp(ax.get_xticklabels(), rotation=20)
    fig.tight_layout()
    return fig


def category_pie_chart(records: list[Record]):
    """Pie chart of each category share."""
    totals = totals_by_category(records)
    if not totals:
        return _empty_fig("Distribution by Category")
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.pie(
        list(totals.values()), labels=list(totals.keys()), autopct="%1.1f%%",
        startangle=90, colors=COLORS[: len(totals)], wedgeprops={"edgecolor": "white"},
    )
    ax.set_title("Distribution of Recycled Material")
    fig.tight_layout()
    return fig


def daily_trend_chart(records: list[Record]):
    """Daily kg line with cumulative total on a second axis."""
    daily = totals_by_date(records)
    if not daily:
        return _empty_fig("Daily Collection Trend")
    from datetime import datetime

    dates = [datetime.strptime(d, "%Y-%m-%d") for d in daily]
    vals = list(daily.values())
    cumulative, running = [], 0.0
    for v in vals:
        running += v
        cumulative.append(running)

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(dates, vals, marker="o", color="#2e7d32", label="Daily kg")
    ax.set_ylabel("Daily weight (kg)", color="#2e7d32")
    ax2 = ax.twinx()
    ax2.plot(dates, cumulative, color="#1565c0", linestyle="--", label="Cumulative kg")
    ax2.set_ylabel("Cumulative (kg)", color="#1565c0")
    ax.set_title("Collection Trend Over Time")
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def goal_progress_chart(records: list[Record]):
    """Horizontal bars of percent-of-goal per category, colour-coded."""
    totals = totals_by_category(records)
    if not records:
        return _empty_fig("Progress Toward Goals")
    cats = list(CATEGORY_GOALS)
    pct = [min(totals.get(c, 0.0) / CATEGORY_GOALS[c] * 100, 150) for c in cats]
    colors = ["#2e7d32" if p >= 100 else "#f9a825" if p >= 60 else "#c62828" for p in pct]
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.barh(cats, pct, color=colors)
    ax.axvline(100, color="black", linestyle="--", linewidth=1)
    for i, p in enumerate(pct):
        ax.text(p + 1, i, f"{p:.0f}%", va="center")
    ax.invert_yaxis()
    ax.set_xlabel("% of goal")
    ax.set_title("Progress Toward Category Goals")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig


def weekday_chart(records: list[Record]):
    """Bar chart of total kg per weekday."""
    if not records:
        return _empty_fig("Collections by Weekday")
    wd = weekday_totals(records)
    fig, ax = plt.subplots(figsize=(7.5, 4))
    bars = ax.bar([d[:3] for d in wd], list(wd.values()), color="#00838f")
    ax.bar_label(bars, fmt="%.0f", padding=2)
    ax.set_ylabel("Weight (kg)")
    ax.set_title("Collections by Weekday")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    return fig


def save_all_charts(records: list[Record], out_dir: Path) -> list[Path]:
    """Save all charts as PNG files for exported reports."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    makers = {
        "category_totals.png": category_bar_chart,
        "category_distribution.png": category_pie_chart,
        "daily_trend.png": daily_trend_chart,
        "goal_progress.png": goal_progress_chart,
        "weekday_pattern.png": weekday_chart,
    }
    paths = []
    for name, maker in makers.items():
        fig = maker(records)
        path = out_dir / name
        fig.savefig(path, dpi=150)
        plt.close(fig)
        paths.append(path)
    return paths
