"""Central configuration: paths, categories, limits and drive goals."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
EXPORT_DIR = BASE_DIR / "exports"
LOG_DIR = BASE_DIR / "logs"
DATA_FILE = DATA_DIR / "recycling_data.json"

APP_NAME = "Recycling Drive Dashboard"

CATEGORIES = ["Plastic", "Paper", "Glass", "Metal", "E-Waste", "Textile", "Organic"]

# Validation limits (kg)
MIN_WEIGHT = 0.1
MAX_WEIGHT = 500.0
MAX_TEXT_LEN = 100

# Drive goals per category (kg) used for status indicators
CATEGORY_GOALS = {
    "Plastic": 150.0,
    "Paper": 200.0,
    "Glass": 120.0,
    "Metal": 100.0,
    "E-Waste": 60.0,
    "Textile": 80.0,
    "Organic": 100.0,
}

# Threshold warning settings
ANOMALY_FACTOR = 3.0        # entry > 3x its category average is flagged
HIGH_ENTRY_KG = 100.0       # any single entry above this is flagged
INACTIVITY_DAYS = 7         # warn if nothing collected for this many days

# Security / robustness limits
MAX_IMPORT_ROWS = 5000          # rows accepted in one bulk import
MAX_UPLOAD_BYTES = 2_000_000    # 2 MB cap on imported CSV files
MAX_RECORDS = 50_000            # hard cap on stored records
