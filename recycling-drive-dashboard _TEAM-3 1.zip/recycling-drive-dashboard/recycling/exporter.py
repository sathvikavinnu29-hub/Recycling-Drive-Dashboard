"""Multi-format export: Markdown report, plain-text audit log, CSV."""
from __future__ import annotations

import csv
import io
from datetime import datetime
from pathlib import Path

from .analytics import build_summary, forecast_goals, generate_insights, generate_warnings
from .config import APP_NAME, EXPORT_DIR
from .models import Record
from .security import escape_markdown, sanitize_csv_cell


def records_to_csv_text(records: list[Record]) -> str:
    """Return all records as CSV text with formula-injection protection."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=Record.field_names())
    writer.writeheader()
    for r in records:
        writer.writerow({k: sanitize_csv_cell(v) for k, v in r.to_dict().items()})
    return buf.getvalue()


def summary_to_markdown(records: list[Record]) -> str:
    """Build the executive summary report in Markdown."""
    s = build_summary(records)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [f"# {APP_NAME} - Summary Report", f"_Generated: {now}_", ""]
    if s["empty"]:
        lines.append("No records available.")
        return "\n".join(lines)
    lines += [
        "## Key Metrics", "",
        f"- **Total collected:** {s['total_kg']} kg across {s['total_entries']} entries",
        f"- **Average per entry:** {s['average_kg']} kg",
        f"- **Average per active day:** {s['avg_per_day']} kg ({s['active_days']} days)",
        f"- **Top category:** {s['top_category']}",
        f"- **Top collector:** {s['top_collector']}",
        f"- **Best day:** {s['best_day'][0]} ({s['best_day'][1]} kg)",
        f"- **Trend (last 7 days):** {s['trend']} ({s['trend_change_pct']:+}%)",
        f"- **Overall goal progress:** {s['overall_goal_percent']}%",
        f"- **Estimated CO2e avoided:** {s['co2_saved_kg']} kg",
        "", "## Category Status", "",
        "| Category | Total (kg) | Goal (kg) | Progress | Status |",
        "|---|---:|---:|---:|---|",
    ]
    for cat, st in s["status"].items():
        lines.append(f"| {cat} | {st['total']:.1f} | {st['goal']:g} | {st['percent']}% | {st['status']} |")
    lines += ["", "## Insights", ""] + [f"- {escape_markdown(i)}" for i in generate_insights(records)]
    lines += ["", "## Goal Forecast", "", "| Category | Rate (kg/day) | Remaining (kg) | Projected goal date |",
              "|---|---:|---:|---|"]
    for f in forecast_goals(records):
        lines.append(f"| {f['category']} | {f['rate_kg_per_day']} | {f['remaining_kg']} | {f['projected_date']} |")
    lines += ["", "## Warnings", ""]
    lines += [f"- {escape_markdown(w)}" for w in generate_warnings(records)] or ["- None"]
    return "\n".join(lines) + "\n"


def audit_log_text(records: list[Record]) -> str:
    """Build a plain-text audit log of every record plus warnings."""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [f"{APP_NAME} - AUDIT LOG", f"Generated: {now}", "=" * 72]
    for r in sorted(records, key=lambda x: (x.date, x.id)):
        lines.append(
            f"[{r.date}] #{r.id:03d} {r.category:<8} {r.weight_kg:>7.2f} kg | "
            f"{r.item} | by {r.collected_by}" + (f" | {r.notes}" if r.notes else "")
        )
    lines += ["=" * 72, f"TOTAL ENTRIES: {len(records)}",
              f"TOTAL WEIGHT : {sum(r.weight_kg for r in records):.2f} kg", "", "WARNINGS:"]
    lines += [f"  * {w}" for w in generate_warnings(records)]
    return "\n".join(lines) + "\n"


def export_all(records: list[Record], out_dir: Path = EXPORT_DIR) -> dict[str, Path]:
    """Write Markdown, audit log and CSV reports to out_dir; return their paths."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    files = {
        "markdown": (out_dir / f"summary_{stamp}.md", summary_to_markdown(records)),
        "audit_log": (out_dir / f"audit_log_{stamp}.txt", audit_log_text(records)),
        "csv": (out_dir / f"records_{stamp}.csv", records_to_csv_text(records)),
    }
    result = {}
    for key, (path, text) in files.items():
        path.write_text(text, encoding="utf-8", newline="")
        result[key] = path
    return result
