"""Bulk CSV import with automatic format validation and row-by-row error log."""
from __future__ import annotations

import csv
import io
from pathlib import Path

from .config import MAX_IMPORT_ROWS, MAX_UPLOAD_BYTES
from .log import get_logger
from .models import Record
from .storage import next_id
from .validation import ValidationError, validate_record_fields

log = get_logger("importer")

REQUIRED_COLUMNS = ["date", "category", "item", "weight_kg", "collected_by"]


def import_csv_text(text: str, existing: list[Record]) -> tuple[list[Record], list[str]]:
    """Parse CSV text. Returns (valid new records, error log lines). Does not save."""
    if len(text.encode("utf-8", errors="ignore")) > MAX_UPLOAD_BYTES:
        return [], [f"File is too large (limit {MAX_UPLOAD_BYTES // 1_000_000} MB)."]
    errors: list[str] = []
    new_records: list[Record] = []
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        return [], ["File is empty or has no header row."]
    headers = [h.strip().lower() for h in reader.fieldnames]
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        return [], [f"Missing required column(s): {', '.join(missing)}. Found: {', '.join(headers)}."]

    next_free = next_id(existing)
    seen = {(r.date, r.category, r.item, r.weight_kg, r.collected_by) for r in existing}
    for line_no, row in enumerate(reader, start=2):  # header is line 1
        if line_no - 1 > MAX_IMPORT_ROWS:
            errors.append(f"Row limit reached: only the first {MAX_IMPORT_ROWS} rows were processed.")
            break
        row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
        try:
            clean = validate_record_fields(row)
            key = (clean["date"], clean["category"], clean["item"], clean["weight_kg"], clean["collected_by"])
            if key in seen:
                raise ValidationError("duplicate of an existing entry")
            seen.add(key)
            new_records.append(Record(id=next_free, **clean))
            next_free += 1
        except ValidationError as exc:
            errors.append(f"Row {line_no}: {exc}")
    log.info("CSV import parsed: %d valid, %d rejected", len(new_records), len(errors))
    return new_records, errors


def import_csv_file(path: Path, existing: list[Record]) -> tuple[list[Record], list[str]]:
    """Import a CSV from disk (size-checked). Returns (valid records, error log)."""
    try:
        if Path(path).stat().st_size > MAX_UPLOAD_BYTES:
            return [], [f"File is too large (limit {MAX_UPLOAD_BYTES // 1_000_000} MB)."]
        text = Path(path).read_text(encoding="utf-8-sig")
    except FileNotFoundError:
        return [], [f"File not found: {path}"]
    except (OSError, UnicodeDecodeError) as exc:
        return [], [f"Could not read file: {exc}"]
    return import_csv_text(text, existing)
