"""Application logging (rotating file + silent fallback if the disk is read-only)."""
from __future__ import annotations

import logging
import logging.handlers

from .config import LOG_DIR

_CONFIGURED = False


def get_logger(name: str = "recycling") -> logging.Logger:
    """Return a child logger of the shared "recycling" logger, configuring file logging once."""
    global _CONFIGURED
    root = logging.getLogger("recycling")
    if not _CONFIGURED:
        root.setLevel(logging.INFO)
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            handler: logging.Handler = logging.handlers.RotatingFileHandler(
                LOG_DIR / "app.log", maxBytes=200_000, backupCount=2, encoding="utf-8"
            )
            handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        except OSError:
            handler = logging.NullHandler()
        root.addHandler(handler)
        root.propagate = False
        _CONFIGURED = True
    return logging.getLogger(name if name.startswith("recycling") else f"recycling.{name}")
