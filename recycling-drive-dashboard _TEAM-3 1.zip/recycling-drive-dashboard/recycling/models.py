"""Data model for a single recycling record."""
from __future__ import annotations

from dataclasses import dataclass, asdict, fields


@dataclass
class Record:
    """One recycling collection entry."""
    id: int
    date: str            # ISO format YYYY-MM-DD
    category: str
    item: str
    weight_kg: float
    collected_by: str
    notes: str = ""

    def to_dict(self) -> dict:
        """Convert to a plain dict for JSON/CSV."""
        return asdict(self)

    @classmethod
    def field_names(cls) -> list[str]:
        """Names of all record fields, in order."""
        return [f.name for f in fields(cls)]
