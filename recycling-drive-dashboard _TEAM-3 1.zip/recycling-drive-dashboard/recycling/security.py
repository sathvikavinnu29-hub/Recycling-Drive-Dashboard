"""Security helpers: spreadsheet-formula neutralising, markdown escaping, safe file paths."""
from __future__ import annotations

from pathlib import Path

from .config import MAX_UPLOAD_BYTES
from .validation import ValidationError

_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def sanitize_csv_cell(value):
    """Neutralise CSV/Excel formula injection (OWASP 'CSV Injection').

    A text cell starting with = + - @ can be executed as a formula when the file is
    opened in Excel, so we prefix such cells with an apostrophe. Non-text values pass through.
    """
    if isinstance(value, str) and value.startswith(_FORMULA_PREFIXES):
        return "'" + value
    return value


def escape_markdown(text: str) -> str:
    """Escape characters that could break a Markdown table or inject markup."""
    for ch in ("\\", "|", "`", "<", ">", "*", "_"):
        text = text.replace(ch, "\\" + ch)
    return text


def safe_csv_path(raw: str) -> Path:
    """Validate a user-supplied path for CSV import (exists, is a .csv file, size-limited)."""
    text = raw.strip().strip('"').strip("'")
    if not text:
        raise ValidationError("Path cannot be blank.")
    path = Path(text).expanduser()
    if path.suffix.lower() != ".csv":
        raise ValidationError("Only .csv files can be imported.")
    try:
        path = path.resolve(strict=True)
    except (FileNotFoundError, OSError):
        raise ValidationError(f"File not found: {text}")
    if not path.is_file():
        raise ValidationError("That path is not a file.")
    if path.stat().st_size > MAX_UPLOAD_BYTES:
        raise ValidationError(f"File is too large (limit {MAX_UPLOAD_BYTES // 1_000_000} MB).")
    return path
