"""JSON persistence with corruption handling and schema checks."""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path

from .config import DATA_FILE, MAX_RECORDS
from .log import get_logger
from .models import Record
from .validation import ValidationError, validate_record_fields


log = get_logger("storage")


def _backup_corrupt(path: Path) -> None:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_suffix(f".corrupt_{stamp}.json")
    try:
        shutil.copy(path, backup)
        log.warning("Corrupt data file backed up to %s", backup.name)
    except OSError:
        log.error("Could not back up corrupt data file %s", path)


def save_records(records: list[Record], path: Path = DATA_FILE) -> None:
    """Atomically write records to JSON (write temp file, then replace)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    payload = {"version": 1, "records": [r.to_dict() for r in records]}
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)
    tmp.replace(path)


def load_records(path: Path = DATA_FILE) -> tuple[list[Record], list[str]]:
    """Load records. Never crashes: returns (records, messages).

    * Missing file  -> creates a clean template and returns [].
    * Corrupt JSON  -> backs the file up, creates a clean template.
    * Bad rows      -> skipped and reported in messages.
    """
    path = Path(path)
    messages: list[str] = []
    try:
        with open(path, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
    except FileNotFoundError:
        save_records([], path)
        return [], [f"No data file found - created a new one at {path.name}."]
    except json.JSONDecodeError:
        _backup_corrupt(path)
        save_records([], path)
        return [], ["Data file was corrupted - backed it up and started a fresh one."]
    except OSError as exc:
        return [], [f"Could not read data file: {exc}"]

    raw_records = payload.get("records") if isinstance(payload, dict) else payload
    if not isinstance(raw_records, list):
        _backup_corrupt(path)
        save_records([], path)
        return [], ["Data file had an invalid structure - backed it up and started fresh."]

    records: list[Record] = []
    seen_ids: set[int] = set()
    for index, raw in enumerate(raw_records, start=1):
        try:
            if not isinstance(raw, dict):
                raise ValidationError("row is not an object")
            clean = validate_record_fields(raw)
            rec_id = int(raw["id"])
            if rec_id in seen_ids:
                raise ValidationError(f"duplicate id {rec_id}")
            seen_ids.add(rec_id)
            records.append(Record(id=rec_id, **clean))
        except (ValidationError, KeyError, TypeError, ValueError) as exc:
            messages.append(f"Skipped stored row {index}: {exc}")
    return records, messages


def next_id(records: list[Record]) -> int:
    """Return the next unused record id."""
    return max((r.id for r in records), default=0) + 1


def add_record(records: list[Record], raw: dict, path: Path = DATA_FILE) -> Record:
    """Validate, append and persist a new record. Raises ValidationError."""
    if len(records) >= MAX_RECORDS:
        raise ValidationError(f"Record limit reached ({MAX_RECORDS}).")
    clean = validate_record_fields(raw)
    record = Record(id=next_id(records), **clean)
    records.append(record)
    save_records(records, path)
    log.info("Added record #%d (%s, %.2f kg)", record.id, record.category, record.weight_kg)
    return record


def delete_record(records: list[Record], record_id: int, path: Path = DATA_FILE) -> bool:
    """Delete a record by id and persist; return True if it existed."""
    for i, rec in enumerate(records):
        if rec.id == record_id:
            del records[i]
            save_records(records, path)
            log.info("Deleted record #%d", record_id)
            return True
    return False


def update_record(records: list[Record], record_id: int, raw: dict, path: Path = DATA_FILE) -> Record:
    """Validate and replace an existing record, then persist. Raises ValidationError."""
    clean = validate_record_fields(raw)
    for i, rec in enumerate(records):
        if rec.id == record_id:
            records[i] = Record(id=record_id, **clean)
            save_records(records, path)
            log.info("Updated record #%d", record_id)
            return records[i]
    raise ValidationError(f"No record with id {record_id}.")
