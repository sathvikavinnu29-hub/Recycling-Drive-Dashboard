"""Defensive input validation shared by the terminal app, the UI and the importer.

Every validator takes raw input (usually a string) and either returns a clean,
correctly typed value or raises ValidationError with a human-friendly message.
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime

from .config import CATEGORIES, MAX_TEXT_LEN, MAX_WEIGHT, MIN_WEIGHT


class ValidationError(ValueError):
    """Raised when user input does not meet the domain constraints."""


def validate_date(value, allow_future: bool = False) -> str:
    """Return an ISO date string, or raise ValidationError (blank, malformed, future, too old)."""
    if isinstance(value, datetime):
        value = value.date()
    if isinstance(value, date):
        parsed = value
    else:
        text = str(value).strip()
        if not text:
            raise ValidationError("Date cannot be blank (use YYYY-MM-DD).")
        try:
            parsed = datetime.strptime(text, "%Y-%m-%d").date()
        except ValueError:
            raise ValidationError(f"'{text}' is not a valid date. Use YYYY-MM-DD, e.g. 2026-11-20.")
    if not allow_future and parsed > date.today():
        raise ValidationError("Date cannot be in the future.")
    if parsed.year < 2000:
        raise ValidationError("Date is too old (year must be 2000 or later).")
    return parsed.isoformat()


def validate_category(value) -> str:
    """Return the canonical category name (case-insensitive) or raise ValidationError."""
    text = str(value).strip()
    if not text:
        raise ValidationError("Category cannot be blank.")
    for cat in CATEGORIES:
        if cat.lower() == text.lower():
            return cat
    raise ValidationError(f"Unknown category '{text}'. Choose from: {', '.join(CATEGORIES)}.")


def validate_weight(value) -> float:
    """Return a weight in kg rounded to 2 dp, enforcing MIN_WEIGHT..MAX_WEIGHT."""
    text = str(value).strip().lower().replace("kg", "").replace(",", "").strip()
    if not text:
        raise ValidationError("Weight cannot be blank.")
    try:
        weight = float(text)
    except ValueError:
        raise ValidationError(f"'{value}' is not a number. Enter weight in kg, e.g. 12.5.")
    if not math.isfinite(weight):
        raise ValidationError("Weight must be a finite number.")
    if weight < MIN_WEIGHT:
        raise ValidationError(f"Weight must be at least {MIN_WEIGHT} kg.")
    if weight > MAX_WEIGHT:
        raise ValidationError(f"Weight cannot exceed {MAX_WEIGHT:g} kg for a single entry.")
    return round(weight, 2)


_TEXT_PATTERN = re.compile(r"^[\w\s\-.,&'()/+]+$", re.UNICODE)


def validate_text(value, field_name: str, required: bool = True) -> str:
    """Return trimmed text, enforcing length, allowed characters and no formula-style start."""
    text = " ".join(str(value).split())  # trims and collapses whitespace
    if not text:
        if required:
            raise ValidationError(f"{field_name} cannot be blank.")
        return ""
    if len(text) > MAX_TEXT_LEN:
        raise ValidationError(f"{field_name} is too long (max {MAX_TEXT_LEN} characters).")
    if not _TEXT_PATTERN.match(text):
        raise ValidationError(f"{field_name} contains unsupported characters.")
    if text[0] in "=@":
        raise ValidationError(f"{field_name} cannot start with '{text[0]}'.")
    return text


def validate_record_fields(raw: dict) -> dict:
    """Validate a full record (without id). Returns cleaned dict or raises ValidationError."""
    return {
        "date": validate_date(raw.get("date", "")),
        "category": validate_category(raw.get("category", "")),
        "item": validate_text(raw.get("item", ""), "Item"),
        "weight_kg": validate_weight(raw.get("weight_kg", "")),
        "collected_by": validate_text(raw.get("collected_by", ""), "Collected by"),
        "notes": validate_text(raw.get("notes", ""), "Notes", required=False),
    }
