"""One-command launcher: installs missing packages, seeds data if needed, opens the web UI.

Usage:  python run.py          (web UI, opens your browser)
        python run.py --cli    (terminal version)
"""
import importlib.util
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED = {"matplotlib": "matplotlib>=3.7", "streamlit": "streamlit>=1.35", "pandas": "pandas>=2.0"}


def missing_packages() -> list[str]:
    """Return pip specs for required packages that are not installed."""
    return [spec for mod, spec in REQUIRED.items() if importlib.util.find_spec(mod) is None]


def install(packages: list[str]) -> bool:
    """pip-install the given packages; return True on success."""
    print(f"Installing required packages: {', '.join(packages)} ...")
    cmd = [sys.executable, "-m", "pip", "install", "--quiet", *packages]
    if subprocess.call(cmd) == 0:
        return True
    # Retry for systems with externally-managed Python
    return subprocess.call(cmd + ["--break-system-packages"]) == 0


def seed_data_if_needed() -> None:
    """Generate sample data on the very first launch."""
    data = ROOT / "data" / "recycling_data.json"
    if not data.exists():
        print("No data file found - generating sample data...")
        subprocess.call([sys.executable, str(ROOT / "generate_sample_data.py")], cwd=ROOT)


def run_cli() -> None:
    """Start the terminal version."""
    subprocess.call([sys.executable, str(ROOT / "cli.py")], cwd=ROOT)


def ensure_streamlit_credentials() -> None:
    """Pre-create Streamlit's credentials file so it never pauses to ask for an email."""
    cred = Path.home() / ".streamlit" / "credentials.toml"
    if not cred.exists():
        try:
            cred.parent.mkdir(parents=True, exist_ok=True)
            cred.write_text('[general]\nemail = ""\n', encoding="utf-8")
        except OSError:
            pass


def main() -> None:
    """Install dependencies if needed, then launch the web UI (or CLI fallback)."""
    seed_data_if_needed()
    if "--cli" in sys.argv:
        needed = [p for p in missing_packages() if p.startswith("matplotlib")]
        if needed and not install(needed):
            print("Could not install matplotlib; charts will not work, but the CLI will still start.")
        run_cli()
        return

    missing = missing_packages()
    if missing and not install(missing):
        print("\nCould not install packages automatically (are you offline?).")
        print("Starting the terminal version instead. Later, run: pip install -r requirements.txt")
        run_cli()
        return

    ensure_streamlit_credentials()
    print("Starting Recycling Drive Dashboard... (press Ctrl+C to stop)")
    try:
        subprocess.call([sys.executable, "-m", "streamlit", "run", str(ROOT / "app.py")], cwd=ROOT)
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
