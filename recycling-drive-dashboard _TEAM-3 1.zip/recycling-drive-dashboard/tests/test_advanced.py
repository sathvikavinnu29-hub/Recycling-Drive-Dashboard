"""Tests for security, forecasting, insights, limits and the CLI input wrapper."""
import csv
import io
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from recycling import analytics, config, exporter, importer, storage
from recycling.models import Record
from recycling.security import escape_markdown, safe_csv_path, sanitize_csv_cell
from recycling.validation import ValidationError, validate_text


def make(id_, d="2026-11-10", cat="Plastic", w=10.0, who="Ana", item="Bottles"):
    return Record(id=id_, date=d, category=cat, item=item, weight_kg=w, collected_by=who)


class SecurityTests(unittest.TestCase):
    def test_formula_injection_neutralised(self):
        for payload in ["=1+1", "+cmd", "-2+3", "@SUM(A1)"]:
            self.assertTrue(sanitize_csv_cell(payload).startswith("'"))
        self.assertEqual(sanitize_csv_cell("Bottles"), "Bottles")
        self.assertEqual(sanitize_csv_cell(12.5), 12.5)

    def test_validation_blocks_formula_start(self):
        for bad in ["=HYPERLINK(1)", "@evil"]:
            with self.assertRaises(ValidationError):
                validate_text(bad, "Item")

    def test_export_csv_is_sanitised(self):
        rec = make(1, item="-2+3")  # '-' is allowed by validation but must be neutralised on export
        rows = list(csv.DictReader(io.StringIO(exporter.records_to_csv_text([rec]))))
        self.assertEqual(rows[0]["item"], "'-2+3")

    def test_markdown_escape(self):
        self.assertEqual(escape_markdown("a|b`c<d>"), "a\\|b\\`c\\<d\\>")

    def test_script_tags_rejected(self):
        with self.assertRaises(ValidationError):
            validate_text("<script>alert(1)</script>", "Notes")

    def test_safe_csv_path(self):
        with tempfile.TemporaryDirectory() as d:
            good = Path(d) / "ok.csv"
            good.write_text("a,b\n1,2\n")
            self.assertEqual(safe_csv_path(str(good)), good.resolve())
            txt = Path(d) / "x.txt"
            txt.write_text("x")
            for bad in ["", str(txt), str(Path(d) / "missing.csv"), d]:
                with self.subTest(bad=bad), self.assertRaises(ValidationError):
                    safe_csv_path(bad)

    def test_import_row_cap(self):
        header = "date,category,item,weight_kg,collected_by\n"
        rows = "".join(f"2026-11-01,Plastic,Item{i},1,Ana\n" for i in range(config.MAX_IMPORT_ROWS + 5))
        new, errors = importer.import_csv_text(header + rows, [])
        self.assertEqual(len(new), config.MAX_IMPORT_ROWS)
        self.assertTrue(any("Row limit" in e for e in errors))

    def test_import_size_cap(self):
        big = "date,category,item,weight_kg,collected_by\n" + "x" * (config.MAX_UPLOAD_BYTES + 10)
        new, errors = importer.import_csv_text(big, [])
        self.assertEqual(new, [])
        self.assertIn("too large", errors[0])

    def test_record_cap(self):
        recs = [make(i) for i in range(1, 4)]
        with tempfile.TemporaryDirectory() as d, mock.patch.object(storage, "MAX_RECORDS", 3):
            with self.assertRaises(ValidationError):
                storage.add_record(recs, {"date": "2026-11-01", "category": "Paper", "item": "A",
                                          "weight_kg": 1, "collected_by": "X"}, Path(d) / "d.json")


class ForecastAndInsightTests(unittest.TestCase):
    def test_forecast_projection(self):
        # 10 days of data, 20 kg plastic -> 2 kg/day; goal 150 -> 130 remaining -> 65 days
        recs = [make(1, "2026-11-01", w=10), make(2, "2026-11-10", w=10)]
        row = next(f for f in analytics.forecast_goals(recs) if f["category"] == "Plastic")
        self.assertEqual(row["rate_kg_per_day"], 2.0)
        self.assertEqual(row["days_to_goal"], 65)
        self.assertEqual(row["projected_date"], "2027-01-14")

    def test_forecast_goal_met_and_empty(self):
        recs = [make(1, "2026-11-01", "Plastic", 200)]
        row = next(f for f in analytics.forecast_goals(recs) if f["category"] == "Plastic")
        self.assertEqual(row["status"], "GOAL MET")
        self.assertEqual(analytics.forecast_goals([]), [])
        no_data = next(f for f in analytics.forecast_goals(recs) if f["category"] == "Glass")
        self.assertEqual(no_data["status"], "NO DATA")

    def test_weekday_totals(self):
        wd = analytics.weekday_totals([make(1, "2026-11-23", w=5), make(2, "2026-11-23", w=3)])
        self.assertEqual(wd["Monday"], 8.0)  # 23 Nov 2026 is a Monday
        self.assertEqual(sum(wd.values()), 8.0)

    def test_insights(self):
        recs = [make(1, "2026-11-23", "Glass", 30), make(2, "2026-11-24", "Paper", 10)]
        text = " ".join(analytics.generate_insights(recs))
        self.assertIn("Glass makes up 75%", text)
        self.assertEqual(len(analytics.generate_insights([])), 1)


class CliInputTests(unittest.TestCase):
    def test_ask_retries_until_valid(self):
        import cli
        from recycling.validation import validate_weight
        with mock.patch("builtins.input", side_effect=["abc", "-1", "999", "7.5"]), \
                mock.patch("builtins.print"):
            self.assertEqual(cli.ask("Weight", validate_weight), 7.5)

    def test_ask_uses_default_on_blank(self):
        import cli
        from recycling.validation import validate_date
        with mock.patch("builtins.input", return_value=""):
            self.assertEqual(cli.ask("Date", validate_date, default="2026-11-01"), "2026-11-01")

    def test_category_by_number(self):
        import cli
        with mock.patch("builtins.input", side_effect=["99", "2"]), mock.patch("builtins.print"):
            self.assertEqual(cli.ask_category(), "Paper")


if __name__ == "__main__":
    unittest.main()
