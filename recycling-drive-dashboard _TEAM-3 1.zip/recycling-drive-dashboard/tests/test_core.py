import json
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from recycling import analytics, exporter, importer, storage
from recycling.models import Record
from recycling.validation import (
    ValidationError, validate_category, validate_date, validate_record_fields,
    validate_text, validate_weight,
)


def make(id_, d="2026-11-10", cat="Plastic", w=10.0, who="Ana", item="Bottles"):
    return Record(id=id_, date=d, category=cat, item=item, weight_kg=w, collected_by=who)


class ValidationTests(unittest.TestCase):
    def test_weight_valid_and_boundaries(self):
        self.assertEqual(validate_weight("12.5"), 12.5)
        self.assertEqual(validate_weight("0.1"), 0.1)
        self.assertEqual(validate_weight("500"), 500.0)
        self.assertEqual(validate_weight(" 7 kg "), 7.0)

    def test_weight_invalid(self):
        for bad in ["", "abc", "-3", "0", "0.05", "500.01", "nan", "inf", "1e999"]:
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                validate_weight(bad)

    def test_date(self):
        self.assertEqual(validate_date("2026-11-01"), "2026-11-01")
        for bad in ["", "01-11-2026", "2026-13-01", "hello"]:
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                validate_date(bad)
        future = (date.today() + timedelta(days=3)).isoformat()
        with self.assertRaises(ValidationError):
            validate_date(future)

    def test_category_case_insensitive(self):
        self.assertEqual(validate_category("  paper "), "Paper")
        self.assertEqual(validate_category("e-waste"), "E-Waste")
        with self.assertRaises(ValidationError):
            validate_category("Plastik")

    def test_text(self):
        self.assertEqual(validate_text("  PET   bottles ", "Item"), "PET bottles")
        with self.assertRaises(ValidationError):
            validate_text("   ", "Item")
        with self.assertRaises(ValidationError):
            validate_text("x" * 101, "Item")
        with self.assertRaises(ValidationError):
            validate_text("<script>", "Item")
        self.assertEqual(validate_text("", "Notes", required=False), "")


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "data.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_file_creates_template(self):
        recs, msgs = storage.load_records(self.path)
        self.assertEqual(recs, [])
        self.assertTrue(self.path.exists())
        self.assertTrue(msgs)

    def test_corrupt_file_recovers(self):
        self.path.write_text("{not valid json", encoding="utf-8")
        recs, msgs = storage.load_records(self.path)
        self.assertEqual(recs, [])
        self.assertTrue(any("corrupt" in m.lower() for m in msgs))
        self.assertTrue(list(Path(self.tmp.name).glob("*.corrupt_*.json")))

    def test_roundtrip_persistence(self):
        recs: list[Record] = []
        storage.add_record(recs, {"date": "2026-11-01", "category": "glass", "item": "Jars",
                                  "weight_kg": "4.5", "collected_by": "Meera", "notes": ""}, self.path)
        loaded, msgs = storage.load_records(self.path)
        self.assertEqual(len(loaded), 1)
        self.assertEqual(loaded[0].category, "Glass")
        self.assertEqual(loaded[0].weight_kg, 4.5)
        self.assertEqual(msgs, [])

    def test_bad_rows_skipped(self):
        payload = {"records": [
            {"id": 1, "date": "2026-11-01", "category": "Paper", "item": "A", "weight_kg": 5, "collected_by": "X"},
            {"id": 2, "date": "bad", "category": "Paper", "item": "A", "weight_kg": 5, "collected_by": "X"},
            {"id": 1, "date": "2026-11-02", "category": "Paper", "item": "B", "weight_kg": 5, "collected_by": "X"},
            "garbage",
        ]}
        self.path.write_text(json.dumps(payload), encoding="utf-8")
        recs, msgs = storage.load_records(self.path)
        self.assertEqual(len(recs), 1)
        self.assertEqual(len(msgs), 3)

    def test_invalid_add_does_not_persist(self):
        recs: list[Record] = []
        with self.assertRaises(ValidationError):
            storage.add_record(recs, {"date": "2026-11-01", "category": "Paper", "item": "A",
                                      "weight_kg": "abc", "collected_by": "X"}, self.path)
        self.assertEqual(recs, [])

    def test_delete_and_update(self):
        recs = [make(1), make(2)]
        storage.save_records(recs, self.path)
        self.assertTrue(storage.delete_record(recs, 1, self.path))
        self.assertFalse(storage.delete_record(recs, 99, self.path))
        storage.update_record(recs, 2, {"date": "2026-11-02", "category": "Metal", "item": "Cans",
                                        "weight_kg": 3, "collected_by": "Z"}, self.path)
        self.assertEqual(recs[0].category, "Metal")
        self.assertEqual(storage.next_id(recs), 3)


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.recs = [
            make(1, "2026-11-01", "Plastic", 10), make(2, "2026-11-01", "Paper", 20),
            make(3, "2026-11-02", "Plastic", 5, "Ben"), make(4, "2026-11-03", "Glass", 15, "Ben", "Jars"),
        ]

    def test_totals(self):
        t = analytics.totals_by_category(self.recs)
        self.assertEqual(t["Plastic"], 15)
        self.assertEqual(list(t)[0], "Paper" if t["Paper"] > 15 else "Plastic")
        self.assertEqual(analytics.totals_by_date(self.recs)["2026-11-01"], 30)

    def test_search(self):
        self.assertEqual(len(analytics.search_records(self.recs, category="plastic")), 2)
        self.assertEqual(len(analytics.search_records(self.recs, keyword="jars")), 1)
        self.assertEqual(len(analytics.search_records(self.recs, date_from="2026-11-02")), 2)
        self.assertEqual(len(analytics.search_records(self.recs, keyword="ben", category="Glass")), 1)
        self.assertEqual(analytics.search_records(self.recs, keyword="zzz"), [])

    def test_summary(self):
        s = analytics.build_summary(self.recs)
        self.assertEqual(s["total_kg"], 50)
        self.assertEqual(s["average_kg"], 12.5)
        self.assertEqual(s["top_category"], "Paper")
        self.assertTrue(analytics.build_summary([])["empty"])

    def test_goal_status(self):
        self.assertEqual(analytics.goal_status(100, 100), "GOAL MET")
        self.assertEqual(analytics.goal_status(70, 100), "ON TRACK")
        self.assertEqual(analytics.goal_status(40, 100), "BEHIND")
        self.assertEqual(analytics.goal_status(5, 100), "CRITICAL")

    def test_warnings(self):
        recs = self.recs + [make(5, "2026-11-04", "Metal", 150)]
        warns = analytics.generate_warnings(recs, today=date(2026, 11, 20))
        self.assertTrue(any(w.startswith("HIGH ENTRY") for w in warns))
        self.assertTrue(any(w.startswith("INACTIVITY") for w in warns))
        self.assertEqual(len(analytics.generate_warnings([])), 1)

    def test_anomaly_detection(self):
        recs = [make(i, "2026-11-05", "Paper", 5) for i in range(1, 6)] + [make(6, "2026-11-05", "Paper", 60)]
        warns = analytics.generate_warnings(recs, today=date(2026, 11, 5))
        self.assertTrue(any(w.startswith("ANOMALY") for w in warns))

    def test_trend(self):
        recs = [make(1, "2026-11-01", w=10), make(2, "2026-11-12", w=30)]
        label, _ = analytics.trend_direction(recs)
        self.assertEqual(label, "RISING")
        self.assertEqual(analytics.trend_direction([])[0], "NO DATA")


class ImportExportTests(unittest.TestCase):
    CSV = (
        "date,category,item,weight_kg,collected_by,notes\n"
        "2026-11-01,Plastic,Bottles,5,Ana,ok\n"
        "2026-11-01,Plastik,Bottles,5,Ana,bad cat\n"
        "2026-11-01,Paper,Box,abc,Ana,bad weight\n"
        "2026-11-01,Plastic,Bottles,5,Ana,dup in file\n"
    )

    def test_import_error_log(self):
        new, errors = importer.import_csv_text(self.CSV, [])
        self.assertEqual(len(new), 1)
        self.assertEqual(len(errors), 3)
        self.assertTrue(errors[0].startswith("Row 3"))

    def test_import_missing_columns(self):
        new, errors = importer.import_csv_text("date,item\n2026-11-01,x\n", [])
        self.assertEqual(new, [])
        self.assertIn("Missing required", errors[0])

    def test_import_assigns_fresh_ids(self):
        new, _ = importer.import_csv_text(self.CSV, [make(7)])
        self.assertEqual(new[0].id, 8)

    def test_import_missing_file(self):
        new, errors = importer.import_csv_file("/no/such/file.csv", [])
        self.assertEqual(new, [])
        self.assertTrue(errors)

    def test_exports(self):
        recs = [make(1), make(2, cat="Glass", w=20)]
        self.assertIn("# Recycling Drive Dashboard", exporter.summary_to_markdown(recs))
        self.assertIn("TOTAL ENTRIES: 2", exporter.audit_log_text(recs))
        self.assertTrue(exporter.records_to_csv_text(recs).startswith("id,date,category"))
        with tempfile.TemporaryDirectory() as d:
            files = exporter.export_all(recs, Path(d))
            self.assertTrue(all(p.exists() for p in files.values()))


class FullRecordTests(unittest.TestCase):
    def test_validate_record_fields(self):
        clean = validate_record_fields({"date": "2026-11-01", "category": "metal", "item": " Cans ",
                                        "weight_kg": "3", "collected_by": "Z"})
        self.assertEqual(clean["category"], "Metal")
        self.assertEqual(clean["item"], "Cans")
        self.assertEqual(clean["notes"], "")


if __name__ == "__main__":
    unittest.main()
